package com.example.laba5

data class Cat2 (
    val catId : Int,
    val catpicurl : String
    )