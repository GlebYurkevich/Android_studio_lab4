package com.example.laba5

data class Cat(
    val catId : String,
    val catPictUrl : String
)