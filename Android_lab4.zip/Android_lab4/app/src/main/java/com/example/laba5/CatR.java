package com.example.laba5;

public class CatR {
}
