package com.example.laba5

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.preference.PreferenceManager
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
            //http://developer.alexanderklimov.ru/android/theory/sharedpreferences.php
        val myPreferences : SharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        catsBreedEditText.setText(myPreferences.getString("catBreed", ""))

        searchButton.setOnClickListener {
            val Editor = myPreferences.edit()
            Editor.remove("catBreed")
            Editor.putString("catBreed", catsBreedEditText.text.toString())
            Editor.apply()
            val intent = Intent(this, CheckCats::class.java)
            val catBreed = catsBreedEditText.text.toString()
            intent.putExtra("catBreed", catBreed)
            startActivity(intent)
        }

        openLastTenButton.setOnClickListener {
            val intent = Intent(this, LastTenActivity::class.java)
            startActivity(intent)
        }
    }
}
